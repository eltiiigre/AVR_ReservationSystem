﻿Partial Class databaseDataSet
    Partial Public Class ReservationDataTable
        Private Sub ReservationDataTable_ReservationRowChanging(sender As Object, e As ReservationRowChangeEvent) Handles Me.ReservationRowChanging

        End Sub

    End Class
End Class

Namespace databaseDataSetTableAdapters

    Partial Public Class ReservationTableAdapter
    End Class
End Namespace

Namespace databaseDataSetTableAdapters
    Partial Public Class ReservationTableAdapter
    End Class
End Namespace
