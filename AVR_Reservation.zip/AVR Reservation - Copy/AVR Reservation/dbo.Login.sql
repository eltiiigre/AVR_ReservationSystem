﻿CREATE TABLE [dbo].[Login] (
    [username] VARCHAR (50) NOT NULL,
    [password] VARCHAR (50) NOT NULL, 
    CONSTRAINT [PK_Login] PRIMARY KEY ([username])
);

